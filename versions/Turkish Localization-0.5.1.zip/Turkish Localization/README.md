# PAYDAY 2 TÜRKÇE YAMA [TURKISH LOCALIZATION]
Merhaba ! 👋

Ben Bruhboy666, ve sizlerle birlikte bu modla birlikteyim. Biliyorsunuz ki bundan 1 yıl önce çıkan Bir Türkçe Yama Modu vardı ancak 1 yıldır güncelleme almıyordu : ( Ben de acaba kendim yapabilir miyim diye düşündüm ve evet, işte karşınızda Payday 2 Türkçe Yama Modu ! Keyfini Çıkarın

## CREDITS

[CENSOR_1337](https://modworkshop.net/user/12851) - String list - String listesi

## EXTRA CREDITS

[Bruhboy345](https://steamcommunity.com/id/bruhboy345/) - Old Turkish Localization Mod Coder - Eski Türkçe Yama mod kodlayıcısı

[OLD TURKISH LOCALIZATION LINK](https://modworkshop.net/mod/34798)

### BİLGİLENDİRME

**Ne yaparsan yap kredi vermeyi unutma**


### NOT 

**ESKİ YAMA KODLARININ KULLANILMASI İÇİN İZİN ALINMIŞTIR.**

[Discord Sunucusu](https://discord.gg/5STMXspFjq)